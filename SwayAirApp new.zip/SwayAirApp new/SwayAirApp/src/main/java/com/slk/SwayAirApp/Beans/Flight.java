package com.slk.SwayAirApp.Beans;



import java.sql.Date;
import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Flight {
	@Id
	private Integer flightId;
	private String flightName;
	private String flightSource;
	private String flightDestination;
	private Date flightDate;
	private Long ticketPrice;
	private Time arrivalTime;
	private Time departureTime;
	private Integer numOfStops;
	private String flightType;
	private Integer seatNumber;
	private Long pnrNumber;

	
	public Flight()
	{}


	public Integer getFlightId() {
		return flightId;
	}


	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}


	public String getFlightName() {
		return flightName;
	}


	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}


	public String getFlightSource() {
		return flightSource;
	}


	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}


	public String getFlightDestination() {
		return flightDestination;
	}


	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}


	public Date getFlightDate() {
		return flightDate;
	}


	public void setFlightDate(Date flightDate) {
		this.flightDate = flightDate;
	}


	public Long getTicketPrice() {
		return ticketPrice;
	}


	public void setTicketPrice(Long ticketPrice) {
		this.ticketPrice = ticketPrice;
	}


	public Time getArrivalTime() {
		return arrivalTime;
	}


	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}


	public Time getDepartureTime() {
		return departureTime;
	}


	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}


	public Integer getNumOfStops() {
		return numOfStops;
	}


	public void setNumOfStops(Integer numOfStops) {
		this.numOfStops = numOfStops;
	}


	public String getFlightType() {
		return flightType;
	}


	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}


	public Integer getSeatNumber() {
		return seatNumber;
	}


	public void setSeatNumber(Integer seatNumber) {
		this.seatNumber = seatNumber;
	}


	public Long getPnrNumber() {
		return pnrNumber;
	}


	public void setPnrNumber(Long pnrNumber) {
		this.pnrNumber = pnrNumber;
	}


	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", flightSource=" + flightSource
				+ ", flightDestination=" + flightDestination + ", flightDate=" + flightDate + ", ticketPrice="
				+ ticketPrice + ", arrivalTime=" + arrivalTime + ", departureTime=" + departureTime + ", numOfStops="
				+ numOfStops + ", flightType=" + flightType + ", seatNumber=" + seatNumber + ", pnrNumber=" + pnrNumber
				+ "]";
	}


	public Flight(Integer flightId, String flightName, String flightSource, String flightDestination, Date flightDate,
			Long ticketPrice, Time arrivalTime, Time departureTime, Integer numOfStops, String flightType,
			Integer seatNumber, Long pnrNumber) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.flightSource = flightSource;
		this.flightDestination = flightDestination;
		this.flightDate = flightDate;
		this.ticketPrice = ticketPrice;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.numOfStops = numOfStops;
		this.flightType = flightType;
		this.seatNumber = seatNumber;
		this.pnrNumber = pnrNumber;
	}

}