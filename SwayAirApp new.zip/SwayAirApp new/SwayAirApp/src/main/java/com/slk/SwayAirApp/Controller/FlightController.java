package com.slk.SwayAirApp.Controller;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.slk.SwayAirApp.Beans.Flight;
import com.slk.SwayAirApp.Service.FlightService;


@RestController
@CrossOrigin
@RequestMapping("/flight.com")
public class FlightController {
	@Autowired
	FlightService service;

	@GetMapping("/flightDetails")
	public List<Flight> getAllFlightDetails() {
		List<Flight> flightList = (List<Flight>) service.getAllFlightDetails();
		return flightList;
	}

	@PostMapping("/addFlight")
	public Flight addFlight(@RequestBody Flight flight) {
		Flight addFlight = service.addFlight(flight);
		return addFlight;
	}

	@PutMapping("/updateFlight/{flightId}")
	public Flight updateFlight(@PathVariable Integer flightId,@RequestBody Flight flight) {

		Flight updateFlight = service.updateFlight(flightId, flight);
		return updateFlight;

	}

	@DeleteMapping("/DeleteFlight/{flightId}")
	public void deleteFlight(@PathVariable Integer flightId) {
		service.deleteFlight(flightId);

	}
	
	// sorting based on departure time and price
	
//	@GetMapping("/filterByPrice")
//    public List<Flight> filterFlightsByPrice(@RequestParam double minPrice, @RequestParam double maxPrice) {
//        return service.filterFlightsByPriceRange(minPrice, maxPrice);
//    }

    @GetMapping("/filterByDepartureTime/{departureTime}/{arrivalTime}")
    public List<Flight> filterFlightsByDepartureTime(@PathVariable Time departureTime, @PathVariable Time arrivalTime) {
        return service.filterFlightsByDepartureTime(departureTime, arrivalTime);
    }

    @GetMapping("/filterByStops/{numOfStops}")
    public List<Flight> filterFlightsByStops(@PathVariable Integer numOfStops) {
        return service.filterFlightsByStops(numOfStops);
    }

    @GetMapping("/filterByType/{flightType}")
    public List<Flight> filterFlightsByType(@PathVariable String flightType) {
        return service.filterFlightsByType(flightType);
    }
    
    //  // search based on destination ,source, date
    @GetMapping("/filterBySourceDestinationDate/{flightSource}/{flightDestination}/{flightDate}")
    public List<Flight>findBySourceDestinationAndDate(@PathVariable String flightSource,@PathVariable String flightDestination,@PathVariable Date flightDate) {
        return service.findBySourceDestinationAndDate( flightSource,flightDestination,flightDate);
    }
    
    
    @GetMapping("/sortFlights/{ticketPrice}/{departureTime}/{arrivalTime}/{numOfStops}/{flightType}")
	public List<Flight> findByPriceDepTimeArrTimeNosTof(@PathVariable Long ticketPrice, @PathVariable Time departureTime,@PathVariable Time arrivalTime,@PathVariable Integer numOfStops,@PathVariable String flightType){
    	return service.findByPriceDepTimeArrTimeNosTof(ticketPrice, departureTime, arrivalTime, numOfStops, flightType);
    	}
}