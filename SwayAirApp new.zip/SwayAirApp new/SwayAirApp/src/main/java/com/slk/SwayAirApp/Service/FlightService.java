package com.slk.SwayAirApp.Service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.SwayAirApp.Beans.Flight;
import com.slk.SwayAirApp.Repository.FlightRepository;



@Service
public class FlightService {
	@Autowired
	FlightRepository repo;

	public List<Flight> getAllFlightDetails() {
		List<Flight> flightList = (List<Flight>) repo.findAll();
		return flightList;
	}

	
	public Flight addFlight( Flight flight) {
		return  repo.save(flight);
		
	}


	public Flight updateFlight( Integer flightId, Flight flight) {
		Flight c = null;
		Optional<Flight> updateFlight = repo.findById(flightId);
		if (updateFlight != null) {
			c = repo.save(flight);
		}
		return c;
	}

	public void deleteFlight( Integer flightId) {
		Flight deleteFlight = repo.findById(flightId).get();
		if (deleteFlight != null) {
			repo.delete(deleteFlight);
		}
	}
	
	//sorting on departure time and price
//	public List<Flight> filterFlightsByPriceRange(double minPrice, double maxPrice) {
//        return repo.findByPriceBetween(minPrice, maxPrice);
//    }

    public List<Flight> filterFlightsByDepartureTime(Time departureTime, Time arrivalTime) {
        return repo.findByDepartureTimeBetween(departureTime, arrivalTime);
    }

    public List<Flight> filterFlightsByStops(Integer numOfStops) {
        return repo.findByNumOfStopsIn(numOfStops);
    }

    public List<Flight> filterFlightsByType(String flightType) {
        return repo.findByFlightType(flightType);
    }
    
    // serch based on dest ,sorce, date
    public List<Flight> findBySourceDestinationAndDate(String flightSource, String flightDestination,Date flightDate) {
        return repo.findByFlightSourceAndFlightDestinationAndFlightDate(flightSource, flightDestination,flightDate);
    }

    public List<Flight> findByPriceDepTimeArrTimeNosTof(Long ticketPrice,Time departureTime, Time arrivalTime, Integer numOfStops, String flightType){
    	return repo.findByTicketPriceAndDepartureTimeAndArrivalTimeAndNumOfStopsAndFlightType(ticketPrice, departureTime, arrivalTime, numOfStops, flightType);
    	}
    
}
    
    
    

	