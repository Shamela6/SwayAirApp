package com.slk.SwayAirApp.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.SwayAirApp.Beans.User;
import com.slk.SwayAirApp.Service.UserService;

	@CrossOrigin
	@RestController
	
	@RequestMapping("/user")
	public class UserController 
	{
		

		@Autowired
		UserService userService;
		
//		@Autowired
//		AuthenticationManager authenticationManager;
		
		@GetMapping("/")
		public String welcome()
		{
			return "Welcome Dear User";
		}
	
		@PostMapping("/register")
		public User  registerUser(@RequestBody User user) throws Exception
		{
		 userService.addUser(user);
			return user;
	     }
		
	
		@PostMapping("/login")
		public User  loginUser(@RequestBody User user) throws Exception
		{
			String res=null;
	      
//	    	 if(  userService.findUser(user)!=null)
//	    	 {
//	    		 res= "login success";//jwtUtil.generateToken(authRequest.getUserName());
//	    	 }
//	    	 else {
//	    		 res= "unsucessful login";
//	    	 
//	    	    
//	    	 }
			return userService.findUser(user);
		}
		
		

	}


