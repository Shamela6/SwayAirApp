package com.slk.SwayAirApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.slk.SwayAirApp.Beans.User;





public interface UserRepository extends JpaRepository<User,String>
{
	User findByUserName(String userName);

	User findByUserNameAndPassword(String userName, String password);
}
