package com.slk.SwayAirApp.Repository;

import java.sql.Date;
import java.sql.Time;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.slk.SwayAirApp.Beans.Flight;


public interface FlightRepository extends JpaRepository<Flight,Integer>{
	 //List<Flight> findByTicketPriceBetween(double minTicketPrice, double maxTicketPrice);
	    List<Flight> findByDepartureTimeBetween(Time departureTime, Time arrivalTime);
	    List<Flight> findByNumOfStopsIn(Integer numOfStops);
	    List<Flight> findByFlightType(String flightType);
	    List<Flight> findByFlightSourceAndFlightDestinationAndFlightDate(String flightSource, String flightDestination,Date flightDate);
	    List<Flight> findByTicketPriceAndDepartureTimeAndArrivalTimeAndNumOfStopsAndFlightType(Long ticketPrice, Time departureTime, Time arrivalTime, Integer numOfStops, String flightType);
}
