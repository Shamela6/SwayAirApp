package com.slk.SwayAirApp.Service;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.slk.SwayAirApp.Beans.Booking;
import com.slk.SwayAirApp.Repository.BookingRepository;

@Service
public class BookingService {
	@Autowired
	BookingRepository bookingRepository;
	
	
	public Booking makeBooking(Booking newBooking) {
		return bookingRepository.save(newBooking);
				} 
	}

