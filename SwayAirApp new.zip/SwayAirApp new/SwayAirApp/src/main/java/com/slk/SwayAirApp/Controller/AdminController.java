package com.slk.SwayAirApp.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.SwayAirApp.Beans.Admin;
import com.slk.SwayAirApp.Service.AdminService;


@CrossOrigin
@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	AdminService adminService;

	@PostMapping("/login")
	public Admin loginAdmin(@RequestBody Admin admin) throws Exception {
//		String res = null;
//
//		if (adminService.findAdmin(admin) != null) {
//			res = "login success";// jwtUtil.generateToken(authRequest.getUserName());
//		} else {
//			res = "unsucessful login";
//
//		}
		return adminService.findAdmin(admin);
	}
	

}

