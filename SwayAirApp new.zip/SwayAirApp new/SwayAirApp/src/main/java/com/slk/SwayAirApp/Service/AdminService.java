package com.slk.SwayAirApp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.SwayAirApp.Beans.Admin;
import com.slk.SwayAirApp.Repository.AdminRepository;


@Service
public class AdminService {
	@Autowired
	AdminRepository repo;

	public Admin findAdmin(Admin admin) {
		Admin adminValidation = repo.findByAdminNameAndAdminPassword(admin.getAdminName(),admin.getAdminPassword());
		if (adminValidation != null) {
			return adminValidation;
		} else {
			return admin;
		}}

	
	
}