package com.slk.SwayAirApp.Beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Admin {

		@Id
		private String adminName;
		private String adminPassword;

		public String getAdminPassword() {
			return adminPassword;
		}

		public String getAdminName() {
			return adminName;
		}

		public Admin(String adminPassword, String adminName) {
			super();
			this.adminPassword = adminPassword;
			this.adminName = adminName;
		}

		@Override
		public String toString() {
			return "Admin [adminPassword=" + adminPassword + ", adminName=" + adminName + "]";
		}

		public Admin() {
			super();
			// TODO Auto-generated constructor stub
		}

	}

