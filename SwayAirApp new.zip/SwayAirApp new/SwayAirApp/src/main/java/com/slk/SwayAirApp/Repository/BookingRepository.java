package com.slk.SwayAirApp.Repository;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.slk.SwayAirApp.Beans.Booking;

@Repository
public interface BookingRepository extends CrudRepository<Booking,BigInteger> {
	
	
}
