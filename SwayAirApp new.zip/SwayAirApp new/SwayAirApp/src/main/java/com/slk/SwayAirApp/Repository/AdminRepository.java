package com.slk.SwayAirApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.slk.SwayAirApp.Beans.Admin;



public interface AdminRepository extends JpaRepository<Admin, String> {

	Admin findByAdminNameAndAdminPassword(String adminName, String adminPassword);
	
	
}
