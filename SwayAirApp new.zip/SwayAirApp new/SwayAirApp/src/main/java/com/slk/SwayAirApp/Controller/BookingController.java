package com.slk.SwayAirApp.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.slk.SwayAirApp.Beans.Booking;
import com.slk.SwayAirApp.Service.BookingService;
@CrossOrigin
@RestController
@RequestMapping("/booking")
public class BookingController {
	@Autowired 
	BookingService bookingService;

	@PostMapping("/makeBooking")
	public Booking addBooking(@RequestBody Booking newBooking) {

		Booking makeBooking=bookingService.makeBooking(newBooking);
		return makeBooking;
	}
}
