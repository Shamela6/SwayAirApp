package com.slk.SwayAirApp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.SwayAirApp.Beans.User;
import com.slk.SwayAirApp.Repository.UserRepository;

	@Service
	public class UserService 
	{
		@Autowired
		 UserRepository userRepository;
		
		
		public void addUser(User user)
		{
//			//user.setPassword(bpe.encode(user.getPassword()));
			
			userRepository.save(user);
		}
		
		public User findUser(User user)
		{
//			//user.setPassword(bpe.encode(user.getPassword()));
			
			User userValidation=userRepository.findByUserNameAndPassword(user.getUserName(),user.getPassword());
			if(userValidation!=null)
			{
				return userValidation;
			}
			else
			{
				return null;
			}
			
		}

	}


